package tienda.modelo;

public interface Persistible {
    String aLinea();
}
